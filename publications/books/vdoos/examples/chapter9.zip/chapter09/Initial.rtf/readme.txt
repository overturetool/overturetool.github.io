This directory contains two files

Enigma_org.rtf
Enigma_org.mdl

The first file is the initial specification of the Enigma
as a Rich Text File, which can be opened with Microsoft Word
(see chapter 9 of the book).

Enigma_org.mdl is the Rational Rose model file which is
constructed using the Rose-Link from VDMTools.

If you wish to experiment with the specification:
- create a new project in VDMTools
- add Enigma_org.rtf to the project
- run syntax- and type checking on the model (no errors)
- start the Rose Link (if you also have Rational Rose)

Good luck!