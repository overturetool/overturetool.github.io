This directory contains four files

Enigma_full.rtf
Enigma_full.mdl
io.vpp
readme.txt (this file)

The first file is the full specification of the Enigma and VDMUnit
as a Rich Text File, which can be opened with Microsoft Word
(see chapter 9 of the book).

Enigma_full.mdl is the Rational Rose model file which is
constructed using the Rose-Link from VDMTools.

If you wish to experiment with the specification:
- create a new project in VDMTools
- add Enigma_full.rtf to the project
- add io.vpp to the project
- run syntax- and type checking on the model (no errors, two warnings)
- go to the interpreter screen
- execute 'print new EnigmaTest().Execute()' which returns 'No errors found'

Good luck!
