Author: Marcel Verhoef


This example is made by Marcel Verhoef and it demonstrates the standard
classical dining philosophers problem expressed in VDM++. The standard 
launcer provided here is sufficient to cover the entire VDM++ model.


Language Version: classic
Entry point     : new Table(2).LetsEat()