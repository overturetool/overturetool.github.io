Author: 




Language Version: classic
Entry point     : new TestClass().Run()