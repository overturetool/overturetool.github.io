Author: Stephen Goldsack


This example deals with quadilaterals (figures with four 
straight lines) and the inheritance between them. A few 
basic operations are defined in the respective classes. 
This package also illustrates how to make use of C++ 
code automatically generated using VDMTools. 


Language Version: classic