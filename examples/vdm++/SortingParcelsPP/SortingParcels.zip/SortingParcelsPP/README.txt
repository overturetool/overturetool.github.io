Author: Bjarke M�holt


The purpose of this VDM++ model is to analyse the rules governing for
distrubuting parcels with different kinds of goods is a
warehouse. This model is made by Bjarke M�holt as a small mini-project
in a course on "Modelling of Mission Critical Systems" (see
https://services.brics.dk/java/courseadmin/TOMoMi/pages/Modelling+of+Mission+Critical+Systems).


Language Version: classic
Entry point     : new Test().Run()