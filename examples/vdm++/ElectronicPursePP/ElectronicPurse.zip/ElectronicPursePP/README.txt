Author: Steve Riddle


This example is made by Steve Riddle as an example for an 
exam question used at the VDM course in Newcastle. It deals
with an electronic purse in a simple form. This is one of the
grand challenges that is considered by the formal methods 
community for formal verification.


Language Version: classic