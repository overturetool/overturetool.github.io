Author: 




Language Version: classic
Entry point     : new Example3().RunTest()