
for ((  i = 0 ;  i <= 500;  i++  ))
do
java -jar ~/.m2/repository/org/overturetool/core/vdmj/2.1.0/vdmj-2.1.0.jar -vdmsl .
done
