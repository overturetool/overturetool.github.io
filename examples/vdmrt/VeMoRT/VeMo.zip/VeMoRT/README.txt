Author: Claus Ballegaard Nielsen


﻿This example was used in the MSc thesis for Claus Ballegaard
Nielsen in order to illustrate how dynamic deployment with advantage 
could be added to VDM-RT.

More information can be found in:
Nielsen, C.B.: Dynamic Reconfiguration of Distributed Systems in VDM-RT. 
Master's thesis, Aarhus University (December 2010).
 

Language Version: classic
Entry point     : new World().Run()