Author: Yves Ledru


﻿This tutorial example is taken out of a VDM course given 
to the students of the Diplôme d'Etudes SupÃ©rieures 
Spécialisées en Génie Informatique (5th year) at the 
Université Joseph Fourier. A first version uses the 
implicit style of specification of VDM-SL and thus may 
not be executed with VDMTools. An explicit version is 
given as an appendix. 


Language Version: classic
Entry point     : SOCCER_EXPL`SUBSTITUTION(3,15)