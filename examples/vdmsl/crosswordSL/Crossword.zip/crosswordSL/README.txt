Author: Yves Ledru



This tutorial example is taken out of a VDM course given to the students 
of the Dipl�me d'Etudes Sup�rieures Sp�cialis�es en G�nie Informatique 
(5th year) at the Universit� Joseph Fourier. This example uses the implicit 
style of specification of VDM-SL and thus may not be executed with the
Overture debugger.



Language Version: classic