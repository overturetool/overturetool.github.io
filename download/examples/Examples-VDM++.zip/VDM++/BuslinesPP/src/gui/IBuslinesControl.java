package gui;

public interface IBuslinesControl {
	
	abstract void IncreaseInflow();
	abstract void DecreaseInflow();
}
