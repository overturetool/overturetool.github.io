Author: Yves Ledru


This model is made by Yves Ledru et al. in a paper illustrating the
combinatorial testing tool called Tobias. In this model the traces to
be used for combinatorial testing purposes have been redone by Peter 
Gorm Larsen. For more information see:

Filtering TOBIAS Combinatorial Test Suites, Yves Ledru, Lydie du 
Bousquet, Olivier Maury and Pierre Bontron, In Fundamental 
Approaches to Software Engineering, Lecture Notes in Computer Science, 
Springer, ISSN 0302-9743 (Print) 1611-3349 (Online), Volume 2984/2004. 
 

Language Version: classic
Entry point     : new Buffers().getBuffers()