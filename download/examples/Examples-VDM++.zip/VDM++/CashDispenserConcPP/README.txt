Author: Sten Agerholm, Peter Gorm Larsen and Kim Sunesen


This model is concurrent and it is described in VDM++. This enables 
abstraction from design considerations and can model errors in the
communication channel and it ensures maximum focus on high-level, 
precise and systematic analysis. This was developed by Sten Agerholm, 
Peter Gorm Larsen and Kim Sunesen in 1999 in connection with FM'99.


Language Version: classic
Entry point     : new Main().Run()