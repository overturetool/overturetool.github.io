Author: Paul Mukherjee


This example is written by Paul Mukherjee and it is used in the VDM++ book
John Fitzgerald, Peter Gorm Larsen, Paul Mukherjee, Nico Plat and Marcel 
Verhoef. Validated Designs for Object-oriented Systems, Springer, New York. 
2005, ISBN 1-85233-881-4. The concurrent system in question is a server 
for the POP3 protocol. This is a protocol supported by all major email c
lients to fetch email messages from the email server. 

Language Version: classic
Entry point     : new POP3Test().Test1()
Entry point     : new POP3Test().Test2()