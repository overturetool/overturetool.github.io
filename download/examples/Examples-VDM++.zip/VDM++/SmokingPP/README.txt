Author: Claus Ballegaard Nielsen




Language Version: vdm10
Entry point     : new World().Run()