package gui;

public interface ISmokingControl {
	
	public abstract void AddPaper(); 

	public abstract void AddMatch(); 
	
	public abstract void AddTobacco(); 
}
