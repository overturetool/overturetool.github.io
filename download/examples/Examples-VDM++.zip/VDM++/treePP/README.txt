Author: 



This VDM++ model contains basic classes for defining 
and traversing over abstract threes and queues.
 

Language Version: classic
Entry point     : new UseTree().insertion_BST()