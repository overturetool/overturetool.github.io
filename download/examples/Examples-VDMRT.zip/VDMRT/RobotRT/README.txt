Author: Lasse Lorentzen and Kenneth Lausdahl


This example was produced by Lasse Lorentzen and Kenneth Lausdahl
as a part of a VDM course of a robot travelling autonomically inside
a cave aiming at avioding different obstacles on its path.

Language Version: classic
Entry point     : new World().Run()