Author: Augusto Ribeiro


This example is created by Augusto Ribeiro illustrating different concepts in VDM 
for teaching purposes including the distributed real time features in VDM-RT. Note
that thus this model is not in a state where it makes sense to execute it.

Language Version: vdm10