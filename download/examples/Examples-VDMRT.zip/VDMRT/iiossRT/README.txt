Author: Christian Thillemann and Bardur Joensen


This project was made by Christian Thillemann and Bardur Joensen in a
VDM course. It is modelling a small subset of a controller for a pig 
stable that wish to keep track of the whereabouts of a collection of pigs
in a stable.

Language Version: vdm10
Entry point     : new World().Run()