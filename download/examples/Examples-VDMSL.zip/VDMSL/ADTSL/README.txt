Author: Matthew Suderman



This work specifies a number of abstract data types (ADT) in
VDM-SL. This includes single-linked lists, double-linked lists,
queues, stacks and binary trees. In addition this work is initiating a
translation from VDM-SL to Modula-2 so system addressing and dynamic 
memory handing is specified in VDM-SL. This work was done by Matthew
Suderman when he was a student at Trinity Western University in the
Spring Semester, 1997.



Language Version: classic
Entry point     : DEFAULT`TestTrees()