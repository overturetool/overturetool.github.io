Author: Anne Haxthausen


This model has been translated by Peter Gorm Larsen from a similar
model made in the RAISE Specification Language by Anne Haxthausen. It
specifies relationships between countries on a map where naboring
countries shall be coloured differently.


Language Version: classic
Entry point     : DEFAULT`colMapExpl({mk_("Denmark","Sweden"),mk_("Denmark","Germany"),mk_("Germany","Poland")})