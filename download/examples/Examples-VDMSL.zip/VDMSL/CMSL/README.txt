Author: Peter Gorm Larsen and Marcel Verhoef


The counter measures example was developed by Peter Gorm Larsen and Marcel 
Verhoef in 2007 in different dialect of VDM. This one is the most abstract 
version using VDM-SL.


Language Version: classic
Entry point     : DEFAULT`CounterMeasures(testval1)
Entry point     : DEFAULT`CounterMeasures(testval2)
Entry point     : DEFAULT`CounterMeasures(testval3)