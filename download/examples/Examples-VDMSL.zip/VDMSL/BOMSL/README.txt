Author: Peter Gorm Larsen


This specification was produced for VDM-SL courses presented by Peter 
Gorm Larsen in 1996. The modelling of a Bill Of Material (BOM) is a rather
standard example making use of an Directed Acyclic Graph (DAG) structure. 


Language Version: classic
Entry point     : DEFAULT`Parts(1,bom)
Entry point     : DEFAULT`Parts(1,cycle)