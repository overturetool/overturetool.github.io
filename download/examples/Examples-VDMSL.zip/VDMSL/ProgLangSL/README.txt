Author: ernhard K. Aichernig and Andreas Kerschbaumer


This example is made by Bernhard K. Aichernig and Andreas Kerschbaumer 
and it contains a VDM model for a Static and Dynamic Semantics of a Simple 
Programming Language. The example has been an assignment in the exercises 
of the software technology course at the Technical University Graz, Austria. 


Language Version: classic
Entry point     : Test`RunTypeCheck()
Entry point     : Test`RunEval()