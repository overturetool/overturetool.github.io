Author: Tomohiro Oda



This example is created by Tomohiro Oda and it illustrates
how it is possible to use higher-order functions in VDM-SL
to create parser elements that can be put together in a 
compositional fashion. This model can be used as a kind of
library that one can play with manipulating strings into a 
VDM AST representation.



Language Version: classic
Entry point     : MMParser`eval("1+1+4+0")