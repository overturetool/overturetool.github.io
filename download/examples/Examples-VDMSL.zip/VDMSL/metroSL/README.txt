Author: Sten Agerholm


This model presents three different abstract specifications of a metro
door management system in VDM-SL. The purpose of the presentation is
to describe alternatives to the Metro specification developed in the
European research project called SPECTRUM. 


Language Version: classic