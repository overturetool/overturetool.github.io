Author: Shin Sahara


This example is made by Shin Sahara as a test of local higher order
functions defined inside explicit function definitions in order to
test the correct interpretation of these constructs.

Language Version: classic
Entry point     : Diet`BMI(100,200)
Entry point     : Diet`getWeightFromBMI(55,76)