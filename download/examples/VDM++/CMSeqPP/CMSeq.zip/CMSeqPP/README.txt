Author: Peter Gorm Larsen and Marcel Verhoef


This example is used in the guidelines for developing distributed 
real time systems using the VICE extension to VDM++. This model 
is available in a sequential version, a concurrent version as
well as in a distributed real-time VICE version. This is the 
distributed real time version of this example. 

Language Version: vdm10
Entry point     : new World().Run()