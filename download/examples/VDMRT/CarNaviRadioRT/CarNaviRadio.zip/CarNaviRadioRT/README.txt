Author: Marcel Verhoef



The origin of the car radio navigation example comes from Marcel
Verhoef as a part of his PhD thesis where it was used to compary
different formalisms. This example shows how an embedded application
with both radio, navigation and traffic messages are joined in one
coherent application in a distributed application.


Language Version: vdm10
Entry point     : new World().RunScenario1()
Entry point     : new World().RunScenario2()