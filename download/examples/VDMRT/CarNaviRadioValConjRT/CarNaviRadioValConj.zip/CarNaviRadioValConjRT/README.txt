Author: Marcel Verhoef



This example is a modified version of the car radio navigation example. It demonstrates the use of validation conjectures.

The origin of the car radio navigation example comes from Marcel Verhoef as a part of his PhD thesis where it was used to compare different formalisms. This example shows how an embedded application with both radio, navigation and traffic messages are joined in one
coherent application in a distributed application.


Language Version: vdm10
Entry point     : new Testing().Test()