Author: John Fitzgerald and Peter Gorm Larsen


This example is made by John Fitgerald and Peter Gorm Larsen and it
is used in the chapter about recursion in the second edition of the 
VDM-SL book. It contains a number of examples for recursive graph 
structures and functionality over such graphs.


Language Version: classic
Entry point     : DEFAULT`AllLabDesc(lgraph,1)