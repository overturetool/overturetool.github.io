Author: V. S. Alagar and D. Muthiayen and K. Periyasamy


Alagar, Muthiayen and Periyasamy have developed formal specifications for 
a Graph Editor using VDM-SL. More information can be found in:

V.S. Alagar, D. Muthiayen and K. Periyasamy, "VDM-SL Specification of a Graph 
Editor", Technical Report, Department of Computer Science, Concordia 
University, Montreal, Canada, May 1996. 


Language Version: classic