Author: V. S. Alagar \and D. Muthiayen


The simulator specified in VDM-SL in this example is the 
main component of an animation tool designed for use in 
the validation of complex real-time reactive systems 
described using TROM (Timed Reactive Object Model) 
formalism. We include two versions of the specifications; 
Section 2 contains the version in which implicit operations 
are used, and most of the operations are rewritten as explicit 
operations in the version contained in Section 3.


Language Version: classic