Author: Bernhard K. Aichernig and Andreas Kerschbaumer


This example is made by Bernhard K. Aichernig and Andreas Kerschbaumer 
and it contains a VDM model for a Static and Dynamic Semantics of a Simple 
Programming Language. The example has been an assignment in the exercises 
of the software technology course at the Technical University Graz, Austria. 


Language Version: vdm10
Entry point     : Test`RunTypeCheck()
Entry point     : Test`RunEval()