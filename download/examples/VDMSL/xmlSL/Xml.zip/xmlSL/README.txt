Author: Tomohiro Oda


This example is a simple AST for XML and utilities to manipulate it.
This model is originally intended to construct SVG models
to specify GUIs for interactive systems.
 

Language Version: vdm10
Entry point     : ViennaDOM`createElement("SVG")